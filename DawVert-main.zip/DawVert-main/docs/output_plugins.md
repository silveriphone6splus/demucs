
# Supported Outputs
## DAWs
| DataType | Short Name | Name |
| --- | --- | :--- |
| R | ```ableton``` | Ableton Live 11 |
| R | ```amped``` | Amped Studio |
| R | ```dawproject``` | dawproject |
| M-I | ```flp``` | FL Studio |
| R | ```lmms``` | LMMS |
| R | ```midi``` | MIDI |
| R | ```muse``` | MusE Sequencer |
| R | ```onlineseq``` | Online Sequencer |
| R | ```reaper``` | Reaper |
| R | ```soundation``` | Soundation |
| R | ```waveform_edit``` | Waveform Edit |
| R | ```wavtool``` | Wavtool |