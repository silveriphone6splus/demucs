 
## VST Plugins (FOSS)



# Samplers

[juicysfplugin](https://github.com/Birch-san/juicysfplugin) - Soundfont 2
 
[Ninjas2](https://github.com/clearly-broken-software/ninjas2) - Slicer

# Synths

[Vital](https://vital.audio/) - Various

# FX

[Airwindows](https://www.airwindows.com/) - Various

[Socalabs](https://socalabs.com/) - Various

# Retro

[Magical 8bit Plug 2](https://github.com/yokemura/Magical8bitPlug2) - Retro

[OPNplug](https://github.com/jpcima/ADLplug) - OPN2, OPL2

[SID](https://socalabs.com/synths/commodore-64-sid/) - C64

# from LMMS

[Vital](https://vital.audio/) - Bitinvader, LB302

[Kickmess](https://github.com/WeirdConstructor/Kickmess) - Kicker

[Zyn-Fusion](https://zynaddsubfx.sourceforge.io/zyn-fusion.html) - ZynAddSubFX

[Wolf Shaper](https://wolf-plugins.github.io/wolf-shaper/) - Waveshaper

[Castello Reverb](https://github.com/lucianoiam/castello/) - ReverbSC

[Socalabs](https://socalabs.com/synths/commodore-64-sid/) - SID, PAPU and Spectrum Analyzer

# from FL Studio

[Ninjas2](https://github.com/clearly-broken-software/ninjas2) - Fruity Slicer

[Kickmess](https://github.com/WeirdConstructor/Kickmess) - Fruit Kick

[Vital](https://vital.audio/) - SimSynth

[mda DX10](https://github.com/topics/mda-plugins/) - Fruity DX10

[Airwindows Weight](https://www.airwindows.com/weight/) - Fruity Bass Boost

[Dragonfly Reverb](https://michaelwillis.github.io/dragonfly-reverb/) - Fruity Reeverb & Fruity Reeverb2

[Spectrum Analyzer](https://socalabs.com/analysis/spectrumanalyzer/) - Fruity Spectroman

[StereoProcessor](https://socalabs.com/effects/stereoprocessor/) - Fruity Stereo Enhancer

[Wolf Shaper](https://wolf-plugins.github.io/wolf-shaper/) - Fruity Waveshaper

[SupaPhaser](https://github.com/bdejong/smartelectronix) - Fruity Phaser

## VST Plugins (Proprietary/Nonfree)

Spaceship Delay

# Synths

Europa

# from FL Studio

Image-Line VST

[GVST](https://www.gvst.co.uk/downloads.htm) - Tuner